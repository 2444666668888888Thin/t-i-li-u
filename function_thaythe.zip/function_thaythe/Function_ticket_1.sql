CREATE OR REPLACE FUNCTION db_23_0853_ancestry_2023.sp_check_consecutive_vowel(
    batch_name character varying,
    field_name character varying,
    num_vowels integer
) RETURNS refcursor LANGUAGE plpgsql
AS $function $
DECLARE 
    var_sql varchar;
    cursor_result refcursor := 'cursor_result';
BEGIN
    /*
     $1: batch name, empty mean all
     $2: fieldname
     $3: number of consecutive vowels
    */
    
    var_sql := concat('
            SELECT data_value as ', quote_ident(field_name), ', amount
            FROM sp_split_single_word_by_field($1, $2)
            WHERE data_value ~* ''[aeiou]{', num_vowels, '}''
            ORDER BY 2 DESC, 1
        ');

    OPEN cursor_result FOR EXECUTE(var_sql) USING batch_name, field_name;
    RETURN cursor_result;
END;
$function $