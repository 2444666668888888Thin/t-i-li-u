CREATE OR REPLACE FUNCTION db_23_0853_ancestry_2023.sp_check_3_consecutive_consonant(
      batch_name character varying,
      field_name character varying,
      n_vowels integer,
      n_consonants integer
) RETURNS refcursor LANGUAGE plpgsql
SET search_path TO 'db_23_0853_ancestry_2023' AS $function $
DECLARE 
  var_condition varchar;
  var_sql varchar;
  cursor_result refcursor := 'cursor_result';
BEGIN
  /*
   $1: batch name, empty mean all
   $2: fieldname
   $3: number of vowels
   $4: number of consonants
   */
  var_sql := '
    SELECT data_value as ' || quote_ident($2) || ', amount
    FROM sp_split_single_word_by_field($1,$2)
    WHERE regexp_replace(data_value, ''[aeiou]'', '''', ''gi'') ~* ''.{''' || n_consonants::varchar || ',}'' AND
          regexp_replace(data_value, ''[^aeiou]'', '''', ''gi'') ~* ''.{''' || n_vowels::varchar || ',}''
    ORDER BY 2 DESC, 1
  ';
  OPEN cursor_result FOR EXECUTE (var_sql) USING $1, $2;
  RETURN cursor_result;
END;
$function $