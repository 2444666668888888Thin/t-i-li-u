CREATE OR REPLACE FUNCTION db_23_0853_ancestry_2023.sp_check_n_consecutive_consonant(
	in_batch_name character varying,
	in_field_name character varying,
	in_n int)
RETURNS refcursor 
LANGUAGE plpgsql
SET search_path TO 'db_23_0853_ancestry_2023' 
AS $function$
DECLARE 
	var_condition varchar;
	var_sql varchar;
	cursor_result refcursor := 'cursor_result';
BEGIN
/*
 in_batch_name: tên batch, empty mean all
 in_field_name: tên field
 in_n: số lượng phụ âm cần lọc
 */
	var_regex varchar := '[b-df-hj-np-tv-z]{' || in_n || '}';
	var_sql := '
			SELECT data_value as ' || quote_ident(in_field_name) || ', amount
			FROM sp_split_single_word_by_field($1,$2)
			WHERE data_value ~* ''' || var_regex || '''
			ORDER BY 2 DESC, 1
		';
	OPEN cursor_result FOR
	EXECUTE
	(var_sql) USING in_batch_name,
	  in_field_name;
	RETURN cursor_result;
END;
$function$